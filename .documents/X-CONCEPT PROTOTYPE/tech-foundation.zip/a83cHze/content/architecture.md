# System Architecture

This document describes the high-level architecture of the platform. The system is designed using a hybrid model that separates the user-facing IDE from the AI execution environment to optimize for performance and security.

### Architecture Diagram

<pre class="mermaid">
graph TD
    subgraph Client-Side (User's Browser)
        direction LR
        UI_Components["UI Components<br>(Dashboard, Wizards)"]
        WebContainer["'Pro Mode' IDE<br>(StackBlitz WebContainer)"]
        UI_Components -- Manages --> WebContainer
    end

    subgraph Backend Services
        Orchestrator["Application Server /<br>Agent Orchestrator"]
    end

    subgraph "AI Execution Environment (E2B)"
        direction TB
        E2B_Runtimes["E2B Secure Cloud Runtimes"]
        subgraph "Isolated Sandboxes"
            direction LR
            Agent1["Agent Sandbox 1"]
            Agent2["Agent Sandbox 2"]
            AgentN["..."]
        end
        E2B_Runtimes -- "Manages & Provisions" --> Agent1
        E2B_Runtimes -- "Manages & Provisions" --> Agent2
        E2B_Runtimes -- "Manages & Provisions" --> AgentN
    end
    
    subgraph "Data & State Management"
        direction TB
        UserDB["User Projects DB<br>(Postgres)"]
        VectorDB["Vector DB<br>(Memory Layers)"]
        DocsDB["Docs & Assets DB<br>(S3/Blobs)"]
    end

    %% --- Connections ---
    WebContainer -- "API Calls (REST/GraphQL)" --> Orchestrator
    Orchestrator -- "Task Dispatch" --> E2B_Runtimes
    E2B_Runtimes -- "Results & Artifacts" --> Orchestrator
    Orchestrator -- "Updates (WebSocket)" --> WebContainer
    
    Orchestrator -- "Read/Write State" --> UserDB
    Orchestrator -- "Read/Write Docs" --> DocsDB
    
    E2B_Runtimes -- "Query/Update Memory" --> VectorDB
    
    style WebContainer fill:#2563eb,stroke:#93c5fd,stroke-width:2px,color:#fff
    style E2B_Runtimes fill:#16a34a,stroke:#86efac,stroke-width:2px,color:#fff
    style Orchestrator fill:#9333ea,stroke:#c4b5fd,stroke-width:2px,color:#fff
    style VectorDB fill:#d97706,stroke:#fcd34d,stroke-width:2px,color:#fff
</pre>

### Interaction Flow

1.  A user request originates from the **WebContainer IDE** and is sent to the **Agent Orchestrator**.
2.  The **Orchestrator** validates the request, creates a task plan, and invokes the **E2B API** to provision a secure sandbox.
3.  The relevant AI agents are loaded into the **E2B sandbox**, where they execute the task, potentially querying the **Vector DB** for context.
4.  Generated artifacts (code, files) are saved to the E2B filesystem.
5.  The **Orchestrator** retrieves the results from the E2B sandbox and updates the project state in the **Primary DB**.
6.  The final files are pushed back to the user's **WebContainer IDE** via a WebSocket connection, completing the loop.
