# UX/UI Design

The user experience is designed to be intuitive and adaptable, catering to different user needs through distinct modes. The UI mockups below illustrate the core components of the platform's interface.

### Dashboard

![Main Dashboard UI](https://r2.flowith.net/files/o/1750610475464-main_dashboard_ui_wireframe_with_prompt_enhancer_and_media_upload_index_0@1024x1024.png)

**Description:** The dashboard is the user's central hub. It features a prominent prompt input area with an integrated "Prompt Enhancer" to help users articulate their ideas clearly. Users can also provide context by uploading files or URLs, which activates specialized agents (like a "Web Cloner") to analyze the input. From here, users can choose their desired creation mode.

### 'Walk-me-through' Flow

![Interactive Walk-me-through UI](https://r2.flowith.net/files/o/1750610473755-interactive_walk_me_through_ui_mockup_design_index_1@1024x1024.png)

**Description:** This mode is a guided, conversational experience. The multi-column layout facilitates a structured dialogue:
- **Left Column:** The AI agent asks clarifying questions to understand the user's goals.
- **Center Column:** The user is presented with clear choices, such as UI layouts, feature sets, or technology stacks. This is where agents like the Front-End Designer present visual options.
- **Right Column:** Provides context, help, or a running summary of the project specifications.

This flow ensures that all necessary requirements are gathered before generation begins, resulting in a more accurate final product.

### 'Pro-Mode' IDE

![Pro-Mode IDE with Documentation Drawer](https://r2.flowith.net/files/o/1750610476616-pro_mode_ide_ui_mockup_with_integrated_documentation_drawer_index_2@1024x1024.png)

**Description:** The "Pro-Mode" provides a full-featured, VS Code-like IDE powered by StackBlitz WebContainer. It offers a familiar three-panel layout:
- **File Explorer (Left):** Shows the complete project file structure.
- **Code Editor (Center):** For manual code editing and refinement.
- **Live Preview / Terminal (Right):** Allows users to see their application running in real-time and interact with the build process.

A key innovation is the **Integrated Documentation Drawer**, which provides persistent access to all generated project documents (plans, diagrams, API specs), ensuring that the project's blueprint is always just a click away.
