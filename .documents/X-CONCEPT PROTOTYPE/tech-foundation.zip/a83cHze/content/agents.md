# Sentient-Core Agents

The platform's intelligence is driven by a hierarchy of specialized AI agents. These agents collaborate to translate user requirements into functional code, orchestrated by a central Application Server.

## High-Level Strategic Agents

These "manager" agents are responsible for project planning, architecture, and high-level decision-making.

| Agent Name | Core Mission |
| :--- | :--- |
| **Research & Analysis Architect** | To interpret the initial user prompt, clarify project requirements, and generate a comprehensive project plan that will guide all subsequent development activities. |
| **Industry-Specific Agent** | To enrich the project plan with domain-specific knowledge, ensuring the application adheres to industry standards, regulations, and best practices. |
| **Front-End Designer** | To translate project requirements and user preferences into a coherent user interface and experience, from wireframes to component design. |
| **Back-End & API Architect** | To design the server-side logic, data persistence layer, and the API contract that connects the front-end to the back-end. |
| **Prototype & Integration Agents** | To orchestrate the initial code generation and assemble the first runnable version of the application by integrating all components and dependencies. |

## Code Domain Synthesizers

These specialized "worker" agents execute granular tasks assigned by the Strategic Agents. They are experts in a single domain and are responsible for generating, regulating, and refactoring code and configuration artifacts.

| Synthesizer | Area of Responsibility | Example Task |
| :--- | :--- | :--- |
| **Front-End** | Generates UI components, styles, and client-side logic. | Create a `UserProfileCard.tsx` React component. |
| **State** | Manages client-side state management libraries. | Implement a Redux slice or Zustand store for a shopping cart. |
| **Hooks** | Creates reusable logic modules for front-end frameworks. | Generate a `useDebounce` custom hook in React. |
| **Backend** | Implements server-side business logic and services. | Write a function to handle password hashing and token generation. |
| **API** | Creates the routing and controller layer for the API. | Build a `POST /api/v1/posts` endpoint controller. |
| **Database** | Writes and executes schema migrations and queries. | Generate a SQL script to add a `last_login` column to a table. |
| **Authentication** | Implements security-critical auth flows. | Configure Passport.js middleware for JWT strategy. |
| **Configuration** | Manages environment variables and tool configuration. | Create a `Dockerfile` for containerization. |
| **Utilities** | Generates common helper functions. | Write a utility function `formatDate(date)`. |
