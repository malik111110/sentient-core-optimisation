document.addEventListener('DOMContentLoaded', () => {
    const contentContainer = document.getElementById('content-container');
    const sidebarNav = document.getElementById('sidebar-nav');

    const sections = [
        { id: 'overview', title: 'Overview', file: 'content/overview.md', icon: 'home' },
        { id: 'technology', title: 'Technology Foundation', file: 'content/technology.md', icon: 'cpu' },
        { id: 'architecture', title: 'System Architecture', file: 'content/architecture.md', icon: 'sitemap' },
        { id: 'ux-ui', title: 'UX/UI Design', file: 'content/ux_ui.md', icon: 'layout-template' },
        { id: 'agents', title: 'Sentient-Core Agents', file: 'content/agents.md', icon: 'bot' },
        { id: 'documentation', title: 'Documentation Standards', file: 'content/documentation.md', icon: 'book-marked' },
        { id: 'roadmap', title: 'Development Roadmap', file: 'content/roadmap.md', icon: 'milestone' },
    ];

    const loadContent = async () => {
        const fetchPromises = sections.map(async (section) => {
            try {
                const response = await fetch(section.file);
                if (!response.ok) throw new Error(`Failed to load ${section.file}`);
                const markdown = await response.text();

                const sectionEl = document.createElement('section');
                sectionEl.id = section.id;
                sectionEl.innerHTML = `<div id="${section.id}-content" class="prose-custom"></div>`;
                contentContainer.appendChild(sectionEl);

                const contentDiv = document.getElementById(`${section.id}-content`);
                contentDiv.innerHTML = marked.parse(markdown);

                if (section.id === 'architecture') {
                    renderMermaidDiagrams(contentDiv);
                }

            } catch (error) {
                console.error(`Error loading section ${section.id}:`, error);
                const sectionEl = document.createElement('section');
                sectionEl.id = section.id;
                sectionEl.innerHTML = `<div class="prose-custom"><h2>${section.title}</h2><p class="text-red-400">Error: Could not load content.</p></div>`;
                contentContainer.appendChild(sectionEl);
            }
        });

        await Promise.all(fetchPromises);
        lucide.createIcons();
        setupScrollSpy();
    };

    const buildSidebar = () => {
        const ul = sidebarNav.querySelector('ul');
        sections.forEach(section => {
            const li = document.createElement('li');
            li.innerHTML = `
                <a href="#${section.id}" data-target-id="${section.id}">
                    <i data-lucide="${section.icon}" class="w-4 h-4"></i>
                    <span>${section.title}</span>
                </a>
            `;
            ul.appendChild(li);
        });
        lucide.createIcons();
    };

    const renderMermaidDiagrams = async (container) => {
        try {
            const mermaid = (await import('https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.js')).default;
            mermaid.initialize({
                startOnLoad: false,
                theme: 'base',
                themeVariables: {
                    background: '#1f2937',
                    primaryColor: '#111827',
                    primaryTextColor: '#d1d5db',
                    lineColor: '#4b5563',
                    nodeBorder: '#4b5563',
                    clusterBkg: '#1f2937',
                    clusterBorder: '#6b7280',
                    mainBkg: '#1f2937',
                    textColor: '#d1d5db',
                }
            });
            const mermaidElements = container.querySelectorAll('pre.mermaid');
            if (mermaidElements.length > 0) {
                 await mermaid.run({
                    nodes: mermaidElements,
                });
            }
        } catch (error) {
            console.error("Mermaid rendering failed:", error);
        }
    };
    
    const setupScrollSpy = () => {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                const id = entry.target.getAttribute('id');
                const link = sidebarNav.querySelector(`a[data-target-id="${id}"]`);
                if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
                    sidebarNav.querySelectorAll('a').forEach(l => l.classList.remove('active'));
                    if (link) {
                        link.classList.add('active');
                    }
                }
            });
        }, { rootMargin: '0px 0px -50% 0px', threshold: 0.5 });

        sections.forEach(section => {
            const el = document.getElementById(section.id);
            if (el) {
                observer.observe(el);
            }
        });
    };

    buildSidebar();
    loadContent();
});
